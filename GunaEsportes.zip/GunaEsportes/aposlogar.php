<!DOCTYPE html>
<html lang="pt-brg">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>GunaEsportes</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/ICON DBE.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,600;1,700&family=Montserrat:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&family=Raleway:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">



  <style>
   .user-image {
            width: 50px; /* Defina o tamanho desejado */
            height: 50px; /* Defina o tamanho desejado */
            border-radius: 50%;
            overflow: hidden;
   }
</style>



  <!-- Template Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Impact
  * Updated: Jul 27 2023 with Bootstrap v5.3.1
  * Template URL: https://bootstrapmade.com/impact-bootstrap-business-website-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->

  
</head>

<body>

  <!-- ======= Header ======= -->
  <section id="topbar" class="topbar d-flex align-items-center">
    <div class="container d-flex justify-content-center justify-content-md-between">
      <div class="contact-info d-flex align-items-center">
        <i class="bi bi-envelope d-flex align-items-center"><a href="mailto:contact@example.com">InstitutoFederal@gmail.com</a></i>
        <i class="bi bi-phone d-flex align-items-center ms-4"><span>+55 11 94759 3848</span></i>
      </div>
    </div>
  </section><!-- End Top Bar -->

 <!-- ... (código anterior) ... -->

 <header id="header" class="header d-flex align-items-center">
    <div class="container-fluid container-xl d-flex align-items-center justify-content-between">
        <a href="aposlogar.php" class="logo d-flex align-items-center">
            <h1>GunaEsportes<span>.</span></h1>
        </a>
        <nav id="navbar" class="navbar">
            <ul>
                <li><a href="#hero">Início</a></li>
                <li><a href="#about">Sobre</a></li>
                <li><a href="#testimonials">Comentários</a></li>
                <li><a href="#portfolio">Atletas</a></li>
                <li><a href="#recent-posts">Notícias</a></li>
                <li><a href="#pricing">Contribuição</a></li>
                <li><a href="#team">Time</a></li>
                <li>
                    <?php
                    session_start();

                    if (isset($_SESSION["caminhoDaImagem"]) && !empty($_SESSION["caminhoDaImagem"])) {
                        $caminhoDaImagem = $_SESSION["caminhoDaImagem"];
                        $nomeUsuario = $_SESSION["usuario"];

                       echo '<li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
        <img class="user-image" src="usuarios/' . $caminhoDaImagem . '" alt="Imagem do Usuário">
        </a>
        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
          <li><a class="dropdown-item" href="#">' . $nomeUsuario . '</a></li>
          <li><hr class="dropdown-divider"></li>
          <li><a class="dropdown-item" href="#" onclick="confirmLogout()">Sair</a></li>
        </ul>
      </li>';
                    } else {
                        echo '<li><a href="log.php"><img src="assets/img/usericon.png" alt="Ícone de Login"> Login</a></li>';
                    }
                    ?>
                </li>
            </ul>
        </nav><!-- .navbar -->
        <i class="mobile-nav-toggle mobile-nav-show bi bi-list"></i>
        <i class="mobile-nav-toggle mobile-nav-hide d-none bi bi-x"></i>
    </div>

</header><!-- End Header -->

<!-- Restante do seu conteúdo HTML aqui -->

<script>
function confirmLogout() {
    var confirmLogout = confirm("Tem certeza que deseja sair?");
    if (confirmLogout) {
        // Redirecione para a página de logout ou faça a ação de logout aqui
        window.location.href = "index.php";
    }
    // Se o usuário clicar em "Cancelar", não faça nada
}
</script>

<!-- ... (restante do código) ... -->

  <!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="hero">
    <div class="container position-relative">
      <div class="row gy-5" data-aos="fade-in">
        <div class="col-lg-6 order-2 order-lg-1 d-flex flex-column justify-content-center text-center text-lg-start">
          <h2>Welcome to <span>Guna esportes</span></h2>
          <p>O site de notícias e acontecimentos dos esportes do Instituto Federal de Guarulhos!</p>
          <div class="d-flex justify-content-center justify-content-lg-start">
            <a href="#about" class="btn-get-started">Acessa ai!</a>
            <a href="https://www.youtube.com/watch?v=LXb3EKWsInQ" class="glightbox btn-watch-video d-flex align-items-center"><i class="bi bi-play-circle"></i><span>Veja Vídeo</span></a>
          </div>
        </div>
        <div class="col-lg-6 order-1 order-lg-2">
          <img src="assets/img/ICON DBE.png" class="img-fluid" alt="" data-aos="zoom-out" data-aos-delay="100">
        </div>
      </div>
    </div>

    <div class="icon-boxes position-relative">
      <div class="container position-relative">
        <div class="row gy-4 mt-5">

          <div class="col-xl-3 col-md-6" data-aos="fade-up" data-aos-delay="100">
            <div class="icon-box">
              <div class="icon"><i class="bi bi-easel"></i></div>
              <h4 class="title">Fotos exclusivas dos atletas</h4>
            </div>
          </div><!--End Icon Box -->

          <div class="col-xl-3 col-md-6" data-aos="fade-up" data-aos-delay="200">
            <div class="icon-box">
              <div class="icon"><i class="bi bi-gem"></i></div>
              <h4 class="title">Principais notícias, eventos e acontecimentos durante o ano </h4>
            </div>
          </div><!--End Icon Box -->

          <div class="col-xl-3 col-md-6" data-aos="fade-up" data-aos-delay="300">
            <div class="icon-box">
              <div class="icon"><i class="bi bi-geo-alt"></i></div>
              <h4 class="title">Tudo sobre o esporte no nosso câmpus</h4>
            </div>
          </div><!--End Icon Box -->

          <div class="col-xl-3 col-md-6" data-aos="fade-up" data-aos-delay="500">
            <div class="icon-box">
              <div class="icon"><i class="bi bi-command"></i></div>
              <h4 class="title">Informações de confiança e qualidade</h4>
            </div>
          </div><!--End Icon Box -->

        </div>
      </div>
    </div>

    </div>
  </section>
  <!-- End Hero Section -->

  <main id="main">

    <!-- ======= About Us Section ======= -->
    <section id="about" class="about">
      <div class="container" data-aos="fade-up">

        <div class="section-header">
          <h1>Sobre o JIF</h1>
          <p>Os Jogos dos Institutos Federais no Brasil têm uma história ligada à promoção de atividades esportivas e culturais entre estudantes de instituições de ensino técnico e tecnológico. Esses jogos visam integrar os alunos, incentivar práticas esportivas e culturais, e fortalecer a identidade das instituições. Eles surgiram após a unificação das escolas técnicas em 2008 sob os Institutos Federais. Os Jogos dos Institutos Federais (JIFs) são eventos anuais que reúnem estudantes de todos os campi em competições esportivas (como futebol, vôlei, atletismo) e culturais (como música, dança, teatro). 
          </p>
        </div>
       <div class="imagem-central">
        <img src="assets/img/Cópia de GUNAAAAA.png" class="img-fluid rounded-4" alt="">
      </div>
<br><br><br>
        <div class="row gy-4">
          <div class="col-lg-6">
        
            <img src="assets/img/uniao_sobre.jpg" class="img-fluid rounded-4 mb-4" alt="">
            <p>Os JIFs ocorrem em etapas regionais, estaduais e nacionais, promovendo talentos e laços entre campi e regiões. Além disso, muitos Institutos Federais organizam eventos esportivos e culturais ao longo do ano, contribuindo para a saúde, bem-estar e desenvolvimento cultural dos estudantes. </p>
            <p>Em suma, os Jogos dos Institutos Federais são uma tradição fundamental na promoção do esporte, cultura e integração estudantil, enriquecendo o desenvolvimento pessoal e acadêmico dos participantes. </p>
          </div>
          <div class="col-lg-6">
            <div class="content ps-0 ps-lg-5">
              <p>
                Os Jogos dos Institutos Federais (JIFs) foram criados no Brasil em 2008, após a unificação das instituições de ensino técnico e tecnológico sob o nome de Institutos Federais. Portanto, os JIFs começaram a ser realizados a partir desse ano.Desde então, os JIFs tornaram-se um evento anual significativo que reúne estudantes de Institutos Federais de todo o país em competições esportivas e culturais, promovendo a integração, o esporte e a cultura entre os alunos das instituições federais de ensino.
              </p>
              
              <p>
                Desde então, os JIFs tornaram-se um evento anual significativo que reúne estudantes de Institutos Federais de todo o país em competições esportivas e culturais, promovendo a integração, o esporte e a cultura entre os alunos das instituições federais de ensino.
                Vale ressaltar que, ao longo dos anos, os JIFs têm crescido em popularidade e participação, tornando-se uma tradição importante para os estudantes dos Institutos Federais no Brasil.
              </p>

              <div class="position-relative mt-4">
                <img src="assets/img/goleiro_sobre.jpg" class="img-fluid rounded-4" alt="">
              </div>
            </div>
          </div>
        </div>

      </div>
    </section><!-- End About Us Section -->

    <!-- ======= Clients Section ======= -->
    <section id="clients" class="clients">
      <div class="container" data-aos="zoom-out">

        <div class="clients-slider swiper">
          <div class="swiper-wrapper align-items-center">
            <div class="swiper-slide"><img src="assets/img/clients/gov.png" class="img-fluid" alt=""></div>
            <div class="swiper-slide"><img src="assets/img/clients/instituto.png" class="img-fluid" alt=""></div>
            <div class="swiper-slide"><img src="assets/img/clients/jogosIF.png" class="img-fluid" alt=""></div>
            <div class="swiper-slide"><img src="assets/img/clients/jif.png" class="img-fluid" alt=""></div>
            <div class="swiper-slide"><img src="assets/img/clients/caixa.jpg" class="img-fluid" alt=""></div>
            <div class="swiper-slide"><img src="assets/img/clients/prato_cheio.jpg" class="img-fluid" alt=""></div>
            <div class="swiper-slide"><img src="assets/img/clients/guarupas.png" class="img-fluid" alt=""></div>
            <div class="swiper-slide"><img src="assets/img/clients/OCG.png" class="img-fluid" alt=""></div>
          </div>
        </div>

      </div>
    </section><!-- End Clients Section -->

    <!-- ======= Stats Counter Section ======= -->
    <section id="stats-counter" class="stats-counter">
      <div class="container" data-aos="fade-up">

        <div class="row gy-4 align-items-center">

          <div class="col-lg-6">
            <img src="assets/img/stats-img.svg" alt="" class="img-fluid">
          </div>

          <div class="col-lg-6">

            <div class="stats-item d-flex align-items-center">
              <span data-purecounter-start="0" data-purecounter-end="14" data-purecounter-duration="1" class="purecounter"></span>
              <p><strong>Quantos Jifs ja tiveram até o ano de 2023?</strong></p>
            </div><!-- End Stats Item -->

            <div class="stats-item d-flex align-items-center">
              <span data-purecounter-start="0" data-purecounter-end="11" data-purecounter-duration="1" class="purecounter"></span>
              <p><strong>Quantas modalidades existem</strong></p>
            </div><!-- End Stats Item -->

            <div class="stats-item d-flex align-items-center">
              <span data-purecounter-start="0" data-purecounter-end="486" data-purecounter-duration="1" class="purecounter"></span>
              <p><strong>Institutos participam do JIF atualmente</strong> </p>
            </div><!-- End Stats Item -->

          </div>

        </div>

      </div>
    </section><!-- End Stats Counter Section -->

    

    
    <!-- ======= Testimonials Section ======= -->
    <section id="testimonials" class="testimonials">
      <div class="container" data-aos="fade-up">

        <div class="section-header">
          <h2>Comentários</h2>
          <p>O que vocês acham sobre o JIF e a OCG?</p>
        </div>

        <div class="slides-3 swiper" data-aos="fade-up" data-aos-delay="100">
          <div class="swiper-wrapper">

            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <div class="d-flex align-items-center">
                    <img src="assets/img/comentários/Juli.jpeg" class="testimonial-img flex-shrink-0" alt="">
                    <div>
                      <h3>Julia Dias</h3>
                      <h4>Atleta de Voleibol</h4>
                      <div class="stars">
                        <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i>
                      </div>
                    </div>
                  </div>
                  <p>
                    <i class="bi bi-quote quote-icon-left"></i>
                    A OCG foi uma explosão de energia! Representar meu colégio no voleibol foi incrível. Enfrentar equipes fortes foi desafiador, mas a camaradagem entre os jogadores é o que mais me marcou. Adorei cada minuto da competição.
                    <i class="bi bi-quote quote-icon-right"></i>
                  </p>
                </div>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <div class="d-flex align-items-center">
                    <img src="assets/img/comentários/sara.jpg" class="testimonial-img flex-shrink-0" alt="">
                    <div>
                      <h3>Sara Ribeiro</h3>
                      <h4>Atleta de Corrida</h4>
                      <div class="stars">
                        <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i>
                      </div>
                    </div>
                  </div>
                  <p>
                    <i class="bi bi-quote quote-icon-left"></i>
                    Correr na OCG foi uma experiência de alta velocidade! As corridas foram intensas, e a pressão era real. Minha maior dificuldade foi controlar a ansiedade antes das corridas. Os JIF me fizeram crescer como atleta.
                    <i class="bi bi-quote quote-icon-right"></i>
                  </p>
                </div>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <div class="d-flex align-items-center">
                    <img src="assets/img/comentários/jailson.jpeg" class="testimonial-img flex-shrink-0" alt="">
                    <div>
                      <h3>Jailson Junior</h3>
                      <h4>Atleta de Basquete e Vôlei</h4>
                      <div class="stars">
                        <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i>
                      </div>
                    </div>
                  </div>
                  <p>
                    <i class="bi bi-quote quote-icon-left"></i>
                    O basquete nos JIF é de alto nível! A dificuldade estava em enfrentar times talentosos de outros colégios. Aprendi muito sobre trabalho em equipe e liderança. Mal posso esperar para a próxima temporada.
                    <i class="bi bi-quote quote-icon-right"></i>
                  </p>
                </div>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <div class="d-flex align-items-center">
                    <img src="assets/img/comentários/Pedro Santos.jpeg" class="testimonial-img flex-shrink-0" alt="">
                    <div>
                      <h3>Pedro Santos</h3>
                      <h4>Atleta de Handebol</h4>
                      <div class="stars">
                        <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i>
                      </div>
                    </div>
                  </div>
                  <p>
                    <i class="bi bi-quote quote-icon-left"></i>
                    O handebol na OCG foi uma experiência intensa! A dificuldade estava em manter a calma nos momentos cruciais. A camaradagem da equipe e a paixão pelo esporte me motivaram a dar o meu melhor.
                    <i class="bi bi-quote quote-icon-right"></i>
                  </p>
                </div>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <div class="d-flex align-items-center">
                    <img src="assets/img/comentários/fernando.jpeg" class="testimonial-img flex-shrink-0" alt="">
                    <div>
                      <h3>Fernando Pinto</h3>
                      <h4>Atleta de Tênis de Mesa</h4>
                      <div class="stars">
                        <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i>
                      </div>
                    </div>
                  </div>
                  <p>
                    <i class="bi bi-quote quote-icon-left"></i>
                    Minha jornada no tênis de mesa através do JIF e da OCG foi emocionante! Em ambas as competições, a adrenalina nas partidas de tênis de mesa era palpável. O desafio estava em encontrar maneiras de superar jogadores habilidosos de diferentes colégios. Representar meu colégio em dois eventos importantes foi uma honra, e as amizades que fiz ao longo do caminho são inestimáveis. Mal posso esperar para continuar treinando e competindo no tênis de mesa.
                    <i class="bi bi-quote quote-icon-right"></i>
                  </p>
                </div>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <div class="d-flex align-items-center">
                    <img src="assets/img/comentários/Pedroso.jpeg" class="testimonial-img flex-shrink-0" alt="">
                    <div>
                      <h3>Pedro Pedroso</P></h3>
                      <h4>Atleta de Voleibol</h4>
                      <div class="stars">
                        <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i>
                      </div>
                    </div>
                  </div>
                  <p>
                    <i class="bi bi-quote quote-icon-left"></i>
                    Ser líbero no voleibol é uma experiência incrível! Meu papel é garantir que a defesa da equipe seja sólida e que as bolas difíceis sejam recuperadas. Embora eu não marque pontos diretamente, desempenho um papel crucial na equipe. É um privilégio representar meu time como líbero e contribuir para nosso sucesso. Vamos continuar treinando e trabalhando juntos para alcançar nossos objetivos no voleibol!
                    <i class="bi bi-quote quote-icon-right"></i>
                  </p>
                </div>
              </div>
            </div><!-- End testimonial item -->

          </div>
          <div class="swiper-pagination"></div>
        </div>

      </div>
    </section><!-- End Testimonials Section -->

    <!-- ======= Portfolio Section ======= -->
    <section id="portfolio" class="portfolio sections-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-header">
          <h1>Atletas mais lindos desse Brasil</h1>
        
        </div>

        <div class="portfolio-isotope" data-portfolio-filter="*" data-portfolio-layout="masonry" data-portfolio-sort="original-order" data-aos="fade-up" data-aos-delay="100">

          <div class="row gy-4 portfolio-container">

            <div class="col-xl-4 col-md-6 portfolio-item filter-app">
              <div class="portfolio-wrap">
                <a href="assets/img/portfolio/clara.jpeg" data-gallery="portfolio-gallery-app" class="glightbox"><img src="assets/img/portfolio/clara.jpg" class="img-fluid" alt=""></a>
                <div class="portfolio-info">
                  <h4><a href="portfolio-details.html" title="More Details">Clara</a></h4>
                  <p>Ponteira do time de voleibol feminino</p>
                </div>
              </div>
            </div><!-- End Portfolio Item -->

            <div class="col-xl-4 col-md-6 portfolio-item filter-product">
              <div class="portfolio-wrap">
                <a href="assets/img/portfolio/coutinho.jpeg" data-gallery="portfolio-gallery-app" class="glightbox"><img src="assets/img/portfolio/coutinho.jpeg" class="img-fluid" alt=""></a>
                <div class="portfolio-info">
                  <h4><a href="portfolio-details.html" title="More Details">Coutinho</a></h4>
                  <p>Líbero do time de voleibol masculino</p>
                </div>
              </div>
            </div><!-- End Portfolio Item -->

            <div class="col-xl-4 col-md-6 portfolio-item filter-branding">
              <div class="portfolio-wrap">
                <a href="assets/img/portfolio/joao.jpeg" data-gallery="portfolio-gallery-app" class="glightbox"><img src="assets/img/portfolio/joao.jpeg" class="img-fluid" alt=""></a>
                <div class="portfolio-info">
                  <h4><a href="portfolio-details.html" title="More Details">Jota</a></h4>
                  <p>Ponteiro do time de voleibol masculino</p>
                </div>
              </div>
            </div><!-- End Portfolio Item -->

            <div class="col-xl-4 col-md-6 portfolio-item filter-books">
              <div class="portfolio-wrap">
                <a href="assets/img/portfolio/baiano.jpeg" data-gallery="portfolio-gallery-app" class="glightbox"><img src="assets/img/portfolio/baiano.jpeg" class="img-fluid" alt=""></a>
                <div class="portfolio-info">
                  <h4><a href="portfolio-details.html" title="More Details">Gustavo ( Baiano )</a></h4>
                  <p>Central do time de voleibol masculino</p>
                </div>
              </div>
            </div><!-- End Portfolio Item -->

            <div class="col-xl-4 col-md-6 portfolio-item filter-app">
              <div class="portfolio-wrap">
                <a href="assets/img/portfolio/matos.jpg" data-gallery="portfolio-gallery-app" class="glightbox"><img src="assets/img/portfolio/matos.jpg" class="img-fluid" alt=""></a>
                <div class="portfolio-info">
                  <h4><a href="portfolio-details.html" title="More Details">Duda Matos</a></h4>
                  <p>Levantadora do time de voleibol feminino</p>
                </div>
              </div>
            </div><!-- End Portfolio Item -->

            <div class="col-xl-4 col-md-6 portfolio-item filter-product">
              <div class="portfolio-wrap">
                <a href="assets/img/portfolio/julia.jpg" data-gallery="portfolio-gallery-app" class="glightbox"><img src="assets/img/portfolio/julia.jpg" class="img-fluid" alt=""></a>
                <div class="portfolio-info">
                  <h4><a href="portfolio-details.html" title="More Details">Julia</a></h4>
                  <p>Ponteira do time de voleibol feminino</p>
                </div>
              </div>
            </div><!-- End Portfolio Item -->

            <div class="col-xl-4 col-md-6 portfolio-item filter-branding">
              <div class="portfolio-wrap">
                <a href="assets/img/comentários/sara.jpg" data-gallery="portfolio-gallery-app" class="glightbox"><img src="assets/img/comentários/sara.jpg" class="img-fluid" alt=""></a>
                <div class="portfolio-info">
                  <h4><a href="portfolio-details.html" title="More Details">Sara R.</a></h4>
                  <p>Atleta de corrida (Atletismo), medalhista de ouro!</p>
                </div>
              </div>
            </div><!-- End Portfolio Item -->

            <div class="col-xl-4 col-md-6 portfolio-item filter-books">
              <div class="portfolio-wrap">
                <a href="assets/img/comentários/Pedroso.jpeg" data-gallery="portfolio-gallery-app" class="glightbox"><img src="assets/img/comentários/Pedroso.jpeg" class="img-fluid" alt=""></a>
                <div class="portfolio-info">
                  <h4><a href="portfolio-details.html" title="More Details">Pedroso</a></h4>
                  <p>Líbero do time de voleibol masculino</p>
                </div>
              </div>
            </div><!-- End Portfolio Item -->

            <div class="col-xl-4 col-md-6 portfolio-item filter-app">
              <div class="portfolio-wrap">
                <a href="assets/img/portfolio/giulia.jpg" data-gallery="portfolio-gallery-app" class="glightbox"><img src="assets/img/portfolio/giulia.jpg" class="img-fluid" alt=""></a>
                <div class="portfolio-info">
                  <h4><a href="portfolio-details.html" title="More Details">Giulia</a></h4>
                  <p>Ponteira do time de voleibol feminino</p>
                </div>
              </div>
            </div><!-- End Portfolio Item -->


            <div class="col-xl-4 col-md-6 portfolio-item filter-books">
              <div class="portfolio-wrap">
                <a href="assets/img/portfolio/xavier.jpg" data-gallery="portfolio-gallery-app" class="glightbox"><img src="assets/img/portfolio/xavier.jpg" class="img-fluid" alt=""></a>
                <div class="portfolio-info">
                  <h4><a href="portfolio-details.html" title="More Details">Xavier</a></h4>
                  <p>Atleta de corrida (Atletismo)</p>
                </div>
              </div>
            </div><!-- End Portfolio Item -->

            <div class="col-xl-4 col-md-6 portfolio-item filter-branding">
              <div class="portfolio-wrap">
                <a href="assets/img/portfolio/borges.jpeg" data-gallery="portfolio-gallery-app" class="glightbox"><img src="assets/img/portfolio/borges.jpeg" class="img-fluid" alt=""></a>
                <div class="portfolio-info">
                  <h4><a href="portfolio-details.html" title="More Details">Borges</a></h4>
                  <p>Levantador do time de voleibol masculino</p>
                </div>
              </div>
            </div><!-- End Portfolio Item -->


            <div class="col-xl-4 col-md-6 portfolio-item filter-product">
              <div class="portfolio-wrap">
                <a href="assets/img/portfolio/nath.jpg" data-gallery="portfolio-gallery-app" class="glightbox"><img src="assets/img/portfolio/nath.jpg" class="img-fluid" alt=""></a>
                <div class="portfolio-info">
                  <h4><a href="portfolio-details.html" title="More Details">Nathalye</a></h4>
                  <p>Ponteira do time de voleibol feminino</p>
                </div>
              </div>
            </div><!-- End Portfolio Item -->


        

            <div class="col-xl-4 col-md-6 portfolio-item filter-books">
              <div class="portfolio-wrap">
                <a href="assets/img/portfolio/neemias.jpg" data-gallery="portfolio-gallery-app" class="glightbox"><img src="assets/img/portfolio/neemias.jpg" class="img-fluid" alt=""></a>
                <div class="portfolio-info">
                  <h4><a href="portfolio-details.html" title="More Details">Neemias</a></h4>
                  <p>  Ala-pivô do time de basquetebol masculino</p>
                </div>
              </div>
            </div><!-- End Portfolio Item -->


            <div class="col-xl-4 col-md-6 portfolio-item filter-branding">
              <div class="portfolio-wrap">
                <a href="assets/img/portfolio/luquinhas.jpg" data-gallery="portfolio-gallery-app" class="glightbox"><img src="assets/img/portfolio/luquinhas.jpg" class="img-fluid" alt=""></a>
                <div class="portfolio-info">
                  <h4><a href="portfolio-details.html" title="More Details">Luquinhas</a></h4>
                  <p>Armador do time de basquetebol masculino</p>
                </div>
              </div>
            </div><!-- End Portfolio Item -->

           

            <div class="col-xl-4 col-md-6 portfolio-item filter-app">
              <div class="portfolio-wrap">
                <a href="assets/img/portfolio/daniel.jpg" data-gallery="portfolio-gallery-app" class="glightbox"><img src="assets/img/portfolio/daniel.jpg" class="img-fluid" alt=""></a>
                <div class="portfolio-info">
                  <h4><a href="portfolio-details.html" title="More Details">Daniel</a></h4>
                  <p>Ala do time de basquetebol masculino</p>
                </div>
              </div>
            </div><!-- End Portfolio Item -->

            <div class="col-xl-4 col-md-6 portfolio-item filter-branding">
              <div class="portfolio-wrap">
                <a href="assets/img/portfolio/henrique.jpg" data-gallery="portfolio-gallery-app" class="glightbox"><img src="assets/img/portfolio/henrique.jpg" class="img-fluid" alt=""></a>
                <div class="portfolio-info">
                  <h4><a href="portfolio-details.html" title="More Details">Henrique</a></h4>
                  <p>Armador do time de basquetebol masculino</p>
                </div>
              </div>
            </div><!-- End Portfolio Item -->

            <div class="col-xl-4 col-md-6 portfolio-item filter-books">
              <div class="portfolio-wrap">
                <a href="assets/img/portfolio/kaua.jpg" data-gallery="portfolio-gallery-app" class="glightbox"><img src="assets/img/portfolio/kaua.jpg" class="img-fluid" alt=""></a>
                <div class="portfolio-info">
                  <h4><a href="portfolio-details.html" title="More Details">Kauã</a></h4>
                  <p>Pivô do time de basquetebol masculino</p>
                </div>
              </div>
            </div><!-- End Portfolio Item -->

            <div class="col-xl-4 col-md-6 portfolio-item filter-app">
              <div class="portfolio-wrap">
                <a href="assets/img/portfolio/jailson.jpg" data-gallery="portfolio-gallery-app" class="glightbox"><img src="assets/img/portfolio/jailson.jpg" class="img-fluid" alt=""></a>
                <div class="portfolio-info">
                  <h4><a href="portfolio-details.html" title="More Details">Jailson</a></h4>
                  <p>Ala-armador do time de basquetebol masculino</p>
                </div>
              </div>
            </div><!-- End Portfolio Item -->

          </div><!-- End Portfolio Container -->

        </div>

      </div>
    </section><!-- End Portfolio Section -->

    

    <!-- ======= Pricing Section ======= -->
    <section id="pricing" class="pricing sections-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-header">
          <h2>Faz o pix aí!</h2>
          <p>Ajude dois progamadores famintos para que o site continue de pé, com atualizações semanais e muitas notícias sobre o esporte fora e dentro do IF de Guarulhos!</p>
        </div>

        <div class="row g-4 py-lg-5" data-aos="zoom-out" data-aos-delay="100">

          <div class="col-lg-4">
            <div class="pricing-item">
              <h3>Pobre premium</h3>
              <div class="icon">
                <i class="bi bi-box"></i>
              </div>
              <h4><sup>$</sup>0<span> / mês</span></h4>
              <ul>
                <li><i class="bi bi-check"></i> Notícias limitadas</li>
                <li><i class="bi bi-check"></i> Acesso a informações sobre o JIF</li>
                <li><i class="bi bi-check"></i> Acesso a fotos limitadas</li>
                <li class="na"><i class="bi bi-x"></i> <span>Notícias completas com informações detalhadas</span></li>
                <li class="na"><i class="bi bi-x"></i> <span>Acesso às fotos dos nossos atletas</span></li>
              </ul>
              <div class="text-center"><a href="#" class="buy-btn">Fazer Pix</a></div>
            </div>
          </div><!-- End Pricing Item -->

          <div class="col-lg-4">
            <div class="pricing-item featured">
              <h3>Nem rico, nem pobre</h3>
              <div class="icon">
                <i class="bi bi-airplane"></i>
              </div>

              <h4><sup>$</sup>29,99<span> / mês</span></h4>
              <ul>
                <li><i class="bi bi-check"></i> Notícias completas</li>
                <li><i class="bi bi-check"></i> Informações detalhadas</li>
                <li><i class="bi bi-check"></i> Acesso ilimitado</li>
                <li><i class="bi bi-check"></i> Perfis de atletas detalhados</li>
                <li><i class="bi bi-check"></i> Histórico de notícias</li>
              </ul>
              <div class="text-center"><a href="#" class="buy-btn">Fazer Pix</a></div>
            </div>
          </div><!-- End Pricing Item -->

          <div class="col-lg-4">
            <div class="pricing-item">
              <h3>Como um atleta!</h3>
              <div class="icon">
                <i class="bi bi-send"></i>
              </div>
              <h4><sup>$</sup>49,99<span> / mês</span></h4>
              <ul>
                <li><i class="bi bi-check"></i> Atualizações em tempo real</li>
                <li><i class="bi bi-check"></i> Fotos exclusivas</li>
                <li><i class="bi bi-check"></i> Ganha um brinde dos colaboradores</li>
                <li><i class="bi bi-check"></i> Notificações personalizadas</li>
                <li><i class="bi bi-check"></i> Acompanhamento de medalhas</li>
              </ul>
              <div class="text-center"><a href="#" class="buy-btn">Fazer Pix</a></div>
            </div>
          </div><!-- End Pricing Item -->

        </div>

      </div>
    </section><!-- End Pricing Section -->

    

    <!-- ======= Recent Blog Posts Section ======= -->
    <section id="recent-posts" class="recent-posts sections-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-header">
          <h1>NOTÍCIAS RECENTES</h1>
        
        </div>

        <div class="row gy-4">

          <div class="col-xl-4 col-md-6">
            <article>

              <div class="post-img">
                <img src="assets/img/meninas_ocg.jfif" alt="" class="img-fluid">
              </div>

              <p class="post-category">OCG</p>

              <h2 class="title">
                <a href="blog-details.html">Meninas ganham sua primeira partida no campeonato de Olímpiadas Colegiais Guarulhense (OCG)</a>
              </h2>

              <div class="d-flex align-items-center">
              
                  <p class="post-date">
                    <time datetime="18/09/2023">Set 18, 2023</time>
                  </p>
              </div>

            </article>
          </div><!-- End post list item -->

          <div class="col-xl-4 col-md-6">
            <article>

              <div class="post-img">
                <img src="assets/img/blog/Instituto federal.png" alt="" class="img-fluid">
              </div>

              <p class="post-category">OCG</p>

              <h2 class="title">
                <a href="blog-details.html">Em sua primeira participação,Instituto Federal termina a 51° OCG em 34° posição com 46 pontos!</a>
              </h2>

              <div class="d-flex align-items-center">
                <div class="post-meta">
                  <p class="post-date">
                    <time datetime="2022-01-01">Set 30, 2023</time>
                  </p>
                </div>
              </div>

            </article>
          </div><!-- End post list item -->

          <div class="col-xl-4 col-md-6">
            <article>

              <div class="post-img">
                <img src="assets/img/xadrez.jpeg" alt="" class="img-fluid">
              </div>

              <p class="post-category">JIF</p>

              <h2 class="title">
                <a href="blog-details.html">Bianca nossa atleta do Xadrez, passa para a etapa regional representando o estado de São Paulo</a>
              </h2>

              <div class="d-flex align-items-center">
                <div class="post-meta">
                  <p class="post-date">
                    <time datetime="2022-01-01">Jun 22, 2022</time>
                  </p>
                </div>
              </div>

            </article>
          </div><!-- End post list item -->

        </div><!-- End recent posts list -->

      </div>
    </section><!-- End Recent Blog Posts Section -->




    <!-- ======= Our Team Section ======= -->
    <section id="team" class="team">
      <div class="container" data-aos="fade-up">

        <div class="section-header">
          <h2>Nosso time</h2>
          <p> Um time de profissioais altamente qualificados são responsáveis pela produção e manutenção do site, são eles: </p>
        </div>

        <div class="row gy-4">

          <div class="col-xl-3 col-md-6 d-flex" data-aos="fade-up" data-aos-delay="100">
            <div class="member">
              <img src="assets/img/team/bruna.png" class="img-fluid" alt="">
              <h4>Bruna Luiza</h4>
              <span> Vagabunda</span>
              <div class="social">
                <a href="https://www.instagram.com/brunalu_z/"><i class="bi bi-instagram"></i></a>
              </div>
            </div>
          </div><!-- End Team Member -->

          <div class="col-xl-3 col-md-6 d-flex" data-aos="fade-up" data-aos-delay="200">
            <div class="member">
              <img src="assets/img/team/Borges.png" class="img-fluid" alt="">
              <h4>Gustavo Borges</h4>
              <span>Vagabundo</span>
              <div class="social">
                <a href="https://www.instagram.com/brogisgu/"><i class="bi bi-instagram"></i></a>
              </div>
            </div>
          </div><!-- End Team Member -->

          <div class="col-xl-3 col-md-6 d-flex" data-aos="fade-up" data-aos-delay="300">
            <div class="member">
              <img src="assets/img/team/renato.png" class="img-fluid" alt="">
              <h4>Renatão</h4>
              <span>Renatão</span>
              <div class="social">
                <a href="https://www.instagram.com/renatobdo81/"><i class="bi bi-instagram"></i></a>
              </div>
            </div>
          </div><!-- End Team Member -->

          <div class="col-xl-3 col-md-6 d-flex" data-aos="fade-up" data-aos-delay="400">
            <div class="member">
              <img src="assets/img/team/JARBAS.png" class="img-fluid" alt="">
              <h4>Jarbas</h4>
              <span>"Serei breve"</span>
              <div class="social">
                <a href="https://www.instagram.com/dr.jarbas.silva/"><i class="bi bi-instagram"></i></a>
              </div>
            </div>
          </div><!-- End Team Member -->

        </div>

      </div>
    </section><!-- End Our Team Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">

    <div class="container">
      <div class="row gy-4">
        <div class="col-lg-5 col-md-12 footer-info">
          <a href="index.html" class="logo d-flex align-items-center">
            <span>GunaEsportes</span>
          </a>
          <p>Eai, se interessou pelo site? Gostou da iniciativa? Cadastre-se para não perder nenhuma novidade!</p>
        </div>

        <div class="col-lg-2 col-6 footer-links">
          <h4>Useful Links</h4>
          <ul>
            <li><a href="#">Início</a></li>
            <li><a href="#">Sobre</a></li>
            <li><a href="#contact ">Cadastro</a></li>
            <li><a href="#">Termos de serviço</a></li>
            <li><a href="#">Política de privacidade</a></li>
          </ul>
        </div>

        <div class="col-lg-3 col-md-12 footer-contact text-center text-md-start">
          <h4>Nos contate!</h4>
          <p>
            Av. Salgado Filho, 3501 - Centro, Guarulhos - SP, 07115-000 <br><br>
            <strong>Phone:</strong> +55 11 94628 3947<br>
            <strong>Email:</strong> InstitutoFederal@gmail.com<br>
          </p>

        </div>

      </div>
    </div>

    <div class="container mt-4">
      <div class="copyright">
        &copy; Copyright <strong><span>GunaEsportes</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/impact-bootstrap-business-website-template/ -->
      </div>
    </div>

  </footer><!-- End Footer -->
  <!-- End Footer -->

  <a href="#" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>



</body>

</html>
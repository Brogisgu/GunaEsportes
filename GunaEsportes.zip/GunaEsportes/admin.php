<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>GunaEsportes</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/ICON DBE.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,600;1,700&family=Montserrat:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&family=Raleway:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  
  <!-- Template Main CSS File -->
  <link href="assets/css/admin.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Impact
  * Updated: Jul 27 2023 with Bootstrap v5.3.1
  * Template URL: https://bootstrapmade.com/impact-bootstrap-business-website-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>



  
<body>
<main>
  <section class="container-admin-banner">
    <img src="assets/img/ICON DBE.png" class="logo-admin" alt="logo-IFSP">
    <h1>Admistração IFSP GunaEsportes</h1>
    <img class= "ornaments" src="assets/img/separador.png" alt="ornaments">
  </section>






  
  <h2>Lista de Usuários</h2>

  <section class="container-table">
    <table>
      <thead>
        <tr>
          <th>Nome</th>
          <th>Email</th>
          <th>Telefone</th>
          <th>senha</th>
          <th>Imagem</th>
          <th colspan="2">Ação</th>
        </tr>
      </thead>
      <?php
      require "conexao.php";
      $sql = "select * from usuario order by nome, imagem ASC";
      $result = $conn->query($sql);

      if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
      ?>

      <tbody>
      <tr>
        <td><?= $row['nome'] ?></td>
        <td><?= $row['email'] ?></td>
        <td><?= $row['telefone'] ?></td>
        <td><?= $row['senha'] ?></td>
        <td><?= $row['imagem'] ?></td>
       
        <td>
        <form action="editar-produto.php" method="GET"> 
          <input type="hidden" name="id" value="<?= $row['id'] ?>">
          <input type="submit" class="botao-editar" value="Editar">
          </form>
        </td>
        <td>
          <form action="excluir-produto.php" method="GET">
            <input type="hidden" name="id" value="<?= $row['id'] ?>">
            <input type="submit" class="botao-excluir" value="Excluir">
          </form>
        </td>
        
      </tr>
      <?php }
                }
                ?>
      </tbody>
    </table>
    <br><br><br><br>        <br><br><br><br>
  </section>
  <script>
    function excluirProduto() {
      event.preventDefault(); // Impede o envio padrão do formulário

      const nome = document.getElementById("nome").value;
      const senha = document.querySelector('senha').value;
      const telefone = document.getElementById("telefone").value;
      const email = document.getElementById("email").value;
      const imagem = document.getElementById("imagem").value;
      const id = document.getElementById("id").value;

      Swal.fire({
        title: "Confirme a edição do produto",
        html: `<strong>Nome:</strong> ${nome}<br>
           <strong>Tipo:</strong> ${senha}<br>
           <strong>Descrição:</strong> ${telefone}<br>
           <strong>Preço:</strong> ${email}<br>
           <strong>Imagem:</strong> ${imagem}<br>`,
        showDenyButton: true,
        
        confirmButtonText: "Editar",
        denyButtonText: "Cancelar",

      }).then((result) => {
        if (result.isConfirmed) {
          // Se o usuário confirmar a edição, redirecione para outra página
          const url = `excluir-produto-sucesso.php?id=${id}`;
          window.location.href = url;
        } else if (result.isDenied) {
          Swal.fire("Edição cancelada", "", "info");
        }
      });
    }
  </script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</main>
</body>
</html>
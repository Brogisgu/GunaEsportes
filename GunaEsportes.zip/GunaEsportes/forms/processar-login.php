<?php
require_once "conexao.php";
session_start();

$email = $_POST["email"];
$senha = $_POST["senha"];

$sql = "SELECT * FROM usuario WHERE email = '$email' AND senha = '$senha'";
$result = $conn->query($sql);

if ($result->num_rows == 1) {
    $row = $result->fetch_assoc();

    $_SESSION["usuario"] = $row["nome"];
    $_SESSION["caminhoDaImagem"] = $row["imagem"];

    header("Location: ../aposlogar.php");
    exit();
} else {
    header("Location: login.php?erro=1");
    exit();
}

$conn->close();
?>
